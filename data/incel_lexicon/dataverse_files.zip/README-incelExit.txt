README

Posts scraped from Reddit's /r/IncelExit forum

Approximately the full archive as of April 5, 2023

reddit-IncelExit-posts.anon.txt is a tab delimited file with the following data:


•	link – a URL or page name that can be mapped to the address of the post
•	comment_id – a unique identifier for each post. 
•	user – the username or screen name of the user who posed 
•	parent – The comment_id of the post being replied to (when applicable)
•	timestamp – the time that the item was posted
•	title – The title of the post. This is available for initial posts in threads but not replies, since replies cannot have separate titles. 
•	text – the text of the post. Formatting and images have been removed

The link field can be mapped to a URL for the post by prepending http://reddit.com 