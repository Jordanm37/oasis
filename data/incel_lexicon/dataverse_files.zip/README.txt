--DATA SOURCES--

This dataset is a collection of the complete accessible archives (as of Spring 2023) from five incel forums:
/r/Incels
/r/Braincels
/r/IncelExit
saidid.net/s/Incels
incels.is


--FORMAT--

For each forum, a tab delimited file is provided that contains:
•	link – a URL or page name that can be mapped to the address of the post
•	comment_id – a unique identifier for each post. 
•	user – the username or screen name of the user who posed. Usernames are anonymized (more on this below)
•	parent – The comment_id of the post being replied to (when applicable)
•	timestamp – the time that the item was posted
•	title – The title of the post. This is available for initial posts in threads but not replies, since replies cannot have separate titles. 
•	text – the text of the post. Formatting and images have been removed


--ANONYMIZATION--

Usernames from all forums are anonymized. In the three Reddit forums (/r/IncelExit, /r/incels, and /r/braincels), anonymization is consistent across platforms (e.g. if "User12345" is anonymized as "1343.523" in /r/braincels, he would also appear as "1343.523" in /r/IncelExit)

Researchers interested in doing work that requires deanonymized usernames, like social network analysis based on replies or looking at posts from reddit users outside the incel community, can contact Prof. Jen Golbeck about collaboration at golbeck@acm.org.

--ADDITIONAL DATA--

There is additional raw data available for certain forums (but are not provided in this repository). Because these files are not anonymized, please reach out to Jen Golbeck golbeck@acm.org about collaboration and access.

Saidit - saidit_html_pages.zip is a folder with the HTML pages scraped to create the dataset.
Incels.is - The HTML pages for each thread that was scraped to generate these files
/r/incels - The raw json collected via the pushshift API. Note that this is assembled from many queries and is likely not a properly formatted JSON file, but all the data is there.


--CODE--
incel.workflow is an Apple Automator script to download the HTML of a webpages from a public forum. We used this
to access post lists and post pages from saidit and incels.is. It can be run as follows where "URL" is replaced with 
the actual URL of the page. Users should open this workflow in Automator and change the download location the the
preferred directory on their computer.

/usr/bin/automator -i "URL" incel.workflow/


--CITATION--

If you use this data, please cite both:

Jennifer Golbeck. (2024). "A dataset for the study of online radicalization through Incel forum archives." Journal of Quantitative Description: Digital Media, 1(2024): 1-29.

and 

Jennifer Golbeck. (2024). "Radicalization and Deradicalization in Online Communities", https://doi.org/10.7910/DVN/MS9ODP, Harvard Dataverse.


--ETHICS--
This data was collected from public archives. It was reviewed by IRB and is not considered Human Subjects Research. However, it contains deleted posts and researchers using this data should be cautious to respect the people whose content is contained here. 

By using this data, you agree to work in accordance with ethical principles for social media research, see Townsend, L., & Wallace, C. (2016). Social media research: A guide to ethics. University of Aberdeen, 1(16).